## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

# Set CRAN mirror to cloud R-project
options(repos = c(CRAN = "https://cloud.r-project.org"))


## -----------------------------------------------------------------------------
library(peakProminence)

## ----include = FALSE----------------------------------------------------------
# Set CRAN mirror to cloud R-project
options(repos = c(CRAN = "https://cloud.r-project.org"))


## -----------------------------------------------------------------------------
# Install devtools if you don't have it
install.packages("devtools")

# Install peakProminence from GitHub
devtools::install_github("HebaAleterji/peak-prominence-calculator/peakProminence")


## -----------------------------------------------------------------------------
# Simulate some data
set.seed(13)
n_comp <- 12
means <- runif(n_comp, -4, 11)
weights <- runif(n_comp, 0.25, 1.1)
weights <- weights / sum(weights)
sigmas <- runif(n_comp, 0.5, 1.5)
x <- seq(-6, 13, length.out = 100)
y <- rep(0, 100)
for (i in 1:n_comp) {
  y <- y + weights[i] * dnorm(x, means[i], sigmas[i])
}

# Plot the simulated data
plot(x, y, type = "l", main = "Simulated Signal", xlab = "Index", ylab = "Value")


## -----------------------------------------------------------------------------
# Detect peaks in the simulated data
peaks <- detect_peaks(y)

# Print the detected peaks
print(peaks)


## -----------------------------------------------------------------------------
# Calculate prominence for the detected peaks
prominence <- calculate_prominence(peaks, y)

# Print the calculated prominence values
print(prominence)


## -----------------------------------------------------------------------------

# Get a data frame with peak information
peak_info <- get_peak_info(peaks, prominence)

# Display the peak information
print(peak_info)


## -----------------------------------------------------------------------------

# Plot the original signal and highlight the detected peaks
plot_peaks(peaks, y)


## -----------------------------------------------------------------------------
# Plot the prominence of each peak
plot_prominence(peaks, prominence, y)


