# tests/test-classes.R
library(testthat)

# Test for Peak class
test_that("Peak class works as expected", {
  # Simulated Peak object
  peaks <- Peak(positions = c(3, 6), heights = c(7, 8))

  # Test the print method for Peak
  expect_output(print(peaks), "Detected Peaks")
  expect_output(print(peaks), "positions")
  expect_output(print(peaks), "heights")

  # Test the summary method for Peak
  expect_output(summary(peaks), "Summary of Detected Peaks")
  expect_output(summary(peaks), "Number of Peaks")
  expect_output(summary(peaks), "Average Peak Height")
})

# Test for Prominence class
test_that("Prominence class works as expected", {
  # Simulated Prominence object
  prominence <- Prominence(positions = c(3, 6), prominences = c(5, 10))

  # Test the print method for Prominence
  expect_output(print(prominence), "Calculated Prominence")
  expect_output(print(prominence), "positions")
  expect_output(print(prominence), "prominences")

  # Test the summary method for Prominence
  expect_output(summary(prominence), "Summary of Peak Prominences")
  expect_output(summary(prominence), "Number of Peaks")
  expect_output(summary(prominence), "Average Prominence")
})



